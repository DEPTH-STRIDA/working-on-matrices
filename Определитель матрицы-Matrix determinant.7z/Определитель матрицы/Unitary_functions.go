package main
import (
	"encoding/json"
	"fmt"
	"io/ioutil"
	"os"
	"math"
)
//Строка куда записывается ход решения.
//Строка куда запишется ошибка, в случае ее возникновения.
type Matrix struct {
	Elements          [][]float64
	Element           []float64
	Sposob            int
	TypeDecomposition string
	Number            int
}
var ErrorDescription string
//Структура, в которую считываются матрицы и дополнительные атрибуты

func (matrixStruct *Matrix)matrix2na2() (s string, f float64) {
	mat:=matrixStruct.Elements
	if len(mat)!=2{
		return "Матрицы размерности не 2x2",0
	}
	f = (mat[0][0]*mat[1][1] - mat[1][0]*mat[0][1])
	s = "(" + fmt.Sprint(mat[0][0]) + ")*(" + fmt.Sprint(mat[1][1]) + ") - (" + fmt.Sprint(mat[1][0]) + ")*(" + fmt.Sprint(mat[0][1]) + ")"
	return s, f
}
func (matrixStruct *Matrix)checkAllElements()bool{
	for index,_:=range matrixStruct.Elements{
		for _,v:=range matrixStruct.Elements[index]{		
			if v!=0{
				return true
			}
		}
	}
	return false
}
func (matrixStruct *Matrix) ReadMatrixFrom(filename string,nameAnswerJSON string)(bool,int){
	file, err := ioutil.ReadFile(filename)
	if err != nil {
		ErrorDescription="Ошибка во время открытия файла: "+err.Error()
		CreateResponseFile(nameAnswerJSON,ErrorDescription,0 )
		return false,0
	}
	data:=[]Matrix{}
	razmer:=0
	err = json.Unmarshal(file, &data)
	if err != nil {
		ErrorDescription="Ошибка во время чтения файла: "+err.Error()
		CreateResponseFile(nameAnswerJSON,ErrorDescription,0 )
		return false,0
	}
	if data[0].Elements != nil {
		    *matrixStruct=data[0]
			tempRazmer := len(data[0].Elements)
			for _, value := range data[0].Elements {
			if tempRazmer!=int(len(value)){
				ErrorDescription="Матрица не является квадратной."
				CreateResponseFile(nameAnswerJSON,ErrorDescription,0 )
				return false,0
			}	
		}
		razmer= tempRazmer
	} else {
		razmer = len(data[0].Element)
		if razmer==0{
			ErrorDescription="Матрица пуста."
			CreateResponseFile(nameAnswerJSON,ErrorDescription,0 )
				return false,0
		}
		*matrixStruct=data[0]
	}
	
	return true,razmer
}
func CheckArguments(inputFile string, outputFile string,lenghtArgs int)bool{
	if lenghtArgs>3{
		ErrorDescription="Слишком много аргументов."
		fmt.Println(ErrorDescription)
		CreateResponseFile(outputFile,ErrorDescription,0 )
		return false
	}
	line1:=(string(inputFile[len(inputFile)-5])+string(inputFile[len(inputFile)-4])+string(inputFile[len(inputFile)-3])+string(inputFile[len(inputFile)-2])+string(inputFile[len(inputFile)-1]))
	line2:=(string(outputFile[len(outputFile)-5])+string(outputFile[len(outputFile)-4])+string(outputFile[len(outputFile)-3])+string(outputFile[len(outputFile)-2])+string(outputFile[len(outputFile)-1]))
	if line1!=".json"{
		ErrorDescription="Неправильно передан аргумент: json с матрицей."
		if line2!=".json"{
			ErrorDescription="Неправильно передан аргумент: json ответа."
			CreateResponseFile(outputFile,ErrorDescription,0 )
			return false
		}	
		CreateResponseFile(outputFile,ErrorDescription,0 )
		return false
	}
	if line2!=".json"{
		ErrorDescription="Неправильно передан аргумента: json ответа."
		CreateResponseFile(outputFile,ErrorDescription,0 )
		return false
	}
	return true
}

func (matrixStruct *Matrix)opredelitel( answer float64, Number int, s string) (string,float64) {
	mat:=matrixStruct.Elements
	return opredelitelInside(mat,0,0,"")
}
func opredelitelInside(mat [][]float64 ,answer float64, Number int, s string)(returnS string, returnF float64){
	if len(mat) == 2 {
		var mat2x2 Matrix
		mat2x2.Elements=mat
		s, a := mat2x2.matrix2na2()
		return s, (answer + a)
	}
	if len(mat) > 2 {
		for i := 0; i < len(mat); i++ {
			newMat := make([][]float64, len(mat)-1)
			indexX := 0
			for X := 0; X < len(mat); X++ {
				for Y := 0; Y < len(mat); Y++ {
					if X != i {
						if Y != Number {
							newMat[indexX] = append(newMat[indexX], mat[X][Y])

							if len(newMat[indexX]) == len(mat)-1 {
								indexX++
							}
						}
					}
				}
			}
			sNow, fNow := opredelitelInside(newMat, 0, 0, s)
			s += fmt.Sprint(mat[i][Number]) + "*(-1)^(" + fmt.Sprint(i+1) + "+" + fmt.Sprint(Number+1) + ")*" + " (" + sNow + ") "
			answer += mat[i][Number] * math.Pow(-1, float64((i+1)+(Number+1))) * fNow
		}

	}
	return s, answer
}
func CreateResponseFile(nameAnswerJSON string,s string,f float64){
	filename := nameAnswerJSON
	type answerJson struct {
		Explanation string `json:"Explanation"`
		Answer string `json:"Answer"`
	}
	value:=fmt.Sprint(f)
    newAnswerJson := &answerJson{
        Explanation: s,
		Answer: value,
    }
	arrayAnswerJson := []answerJson{}
	arrayAnswerJson = append(arrayAnswerJson, *newAnswerJson)
	_, err := os.Create(filename)
	if err != nil {
		fmt.Println(err)
		return
	}
    file, err := ioutil.ReadFile(filename)
    if err != nil {
        fmt.Println(err)
		return
    }
    json.Unmarshal(file, &arrayAnswerJson)	
    dataBytes, err := json.Marshal(arrayAnswerJson)
    if err != nil {
        fmt.Println(err)
		return
    }
    err = ioutil.WriteFile(filename, dataBytes, 0644)
    if err != nil {
		fmt.Println(err)
		return
    }
}
//Структура и функция для конветации ошибок в строку.
type errorString struct {
    s string
}
func (e *errorString) Error() string {
    return e.s
}