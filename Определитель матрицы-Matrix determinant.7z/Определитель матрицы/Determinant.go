// Пакет демонстрирует нахождение определителя матрица несколькими способами.
package main

import (
	"fmt"
	"math"
)

func main() {
	//Структуры с матрицей и способом нахождения определителя.
	M1 := Matrix{Elements: [][]float64{{3, 4, 1, 8}, {3, 1, -2, -5}, {-1, 3, -2, -1}, {1, 2, 3, 4}}, Sposob: 0, TypeDecomposition: "line", Number: 1}
	//Структуры с матрицей и способом нахождения определителя.
	M2 := Matrix{Elements: [][]float64{{3, 4, 1}, {3, 1, -2}, {-1, 3, -2}}, Sposob: 2, TypeDecomposition: "line", Number: 1}
	//Структуры с матрицей и способом нахождения определителя.
	//Для матрицы размерности 2x2 следует указать способ 0 или не указывать вообще. Только этот способ поддерживает нахождение det для 2x2.
	M3 := Matrix{Elements: [][]float64{{3, 4}, {3, 1}}, Sposob: 0, TypeDecomposition: "line", Number: 1}
	//Структуры с матрицей и способом нахождения определителя.
	M4 := Matrix{Element: []float64{3}, Sposob: 2, TypeDecomposition: "line", Number: 1}
	M1.findDet()
	M2.findDet()
	M3.findDet()
	M4.findDet()
	//Как вы могли заменить в некоторые поля могут вообще не учитываться, поэтому случайное их заполнение не создаст ошибки
}
func (M *Matrix) findDet() {
	// Размер и ранг матрицы.
	typeMatrix := 0
	// Строка, содержащяя ход решения.
	DecisionMakingProcess := ""
	//Проверяем правильно ли заполнена структура
	if M.CheckArguments() == false {
		fmt.Println("Структура заполнена неправильно")
		return
	}
	//Определяем одномерная или двумерная матрица в структуре.
	typeMatrix = M.findType()
	//////////////////////////////////////////////////////////////////////////////////////////////////////////
	switch typeMatrix {
	//В структуре одномерная матрица.
	case 0:
		if M.Element[0] != 0 {
			DecisionMakingProcess = "Матрица состоит из одного элемента " + fmt.Sprint(M.Element[0]) + " который не равен нулю. Поэтому определитель матрицы равен: " + fmt.Sprint(M.Element[0])
			fmt.Println(DecisionMakingProcess)
			return
		} else {
			DecisionMakingProcess = "Матрица состоит из одного элемента, который равен нулю. Поэтому определитель матрицы равен: 0"
			fmt.Println("Матрица состоит из одного элемента, который равен нулю. Поэтому определитель матрицы равен: 0")
			return
		}
	//В структуре двумерная матрица
	case 1:
		//
		if M.CheckZero() == false {
			DecisionMakingProcess += "Матрица содержит только нули. Определитель 0\n"
			fmt.Println("Матрица содержит только нули. Определитель 0")
			return
		}
		//Для матрицы можно использовать различные методы нахождения det
		//Определяем способ с помощью switch
		switch M.Sposob {
		//Если спобоб не указан, то структура автоматическ присвоит способу нулевое значение типа: 0
		case 0:
			s, f := M.DecompositionOfDeterminantByElements(DecisionMakingProcess)
			fmt.Println(s, " :", f)
		//Гаусс
		case 1:
			fmt.Println("Вместо Гаусса сейчас заглушка")
			//Треугольника
		case 2:
			s, f := M.treugolnik(DecisionMakingProcess)
			fmt.Println(s, " : ", f)
			//Саррюс
		case 3:
			s, f := M.Sarrus(DecisionMakingProcess)
			fmt.Println(s, " : ", f)
		}

	}
}

// ////////////////////////////////////////////////////////////////////////////////////////////////////////
// Нахождение определителя, разложением по строке или столбцу
func (matrixStruct *Matrix) DecompositionOfDeterminantByElements(s string) (string, float64) {
	mat := matrixStruct.Elements
	//Устанавливаем значение строкка или столбец
	TypeDecomposition := matrixStruct.TypeDecomposition
	//Номер строки или столбца. Если явно не указать значение в структуре, то будет использоваться значение по умалчанию из структуры.
	Number := matrixStruct.Number
	//Важно указать столбец, иначе если не указать, или указать другое то будет использовано разложение по строке.
	if TypeDecomposition == "column" {
		mat = transposeMatrix(mat)
	}
	//Анонимная рекурсивная функция
	var opredelitelInside func([][]float64, float64, int, string) (string, float64)
	opredelitelInside = func(mat [][]float64, answer float64, Number int, s string) (returnS string, returnF float64) {
		if len(mat) == 2 {
			var mat2x2 Matrix
			mat2x2.Elements = mat
			s, a := mat2x2.matrix2na2()
			return s, (answer + a)
		}
		if len(mat) > 2 {
			for i := 0; i < len(mat); i++ {
				newMat := make([][]float64, len(mat)-1)
				indexX := 0
				for X := 0; X < len(mat); X++ {
					for Y := 0; Y < len(mat); Y++ {
						if X != i {
							if Y != Number {
								newMat[indexX] = append(newMat[indexX], mat[X][Y])
								if len(newMat[indexX]) == len(mat)-1 {
									indexX++
								}
							}
						}
					}
				}
				sNow, fNow := opredelitelInside(newMat, 0, 0, s)
				s += fmt.Sprint(mat[i][Number]) + "*(-1)^(" + fmt.Sprint(i+1) + "+" + fmt.Sprint(Number+1) + ")*" + " (" + sNow + ") "
				answer += mat[i][Number] * math.Pow(-1, float64((i+1)+(Number+1))) * fNow
			}

		}
		return s, answer
	}
	s, f := opredelitelInside(mat, 0, Number, s)
	return s, f
}

// Метод для нахождения определителя матрицы размерности 2х2
func (matrixStruct *Matrix) matrix2na2() (s string, f float64) {
	mat := matrixStruct.Elements
	if len(mat) != 2 {
		return "Матрицы размерности не 2x2", 0
	}
	f = (mat[0][0]*mat[1][1] - mat[1][0]*mat[0][1])
	s = "(" + fmt.Sprint(mat[0][0]) + ")*(" + fmt.Sprint(mat[1][1]) + ") - (" + fmt.Sprint(mat[1][0]) + ")*(" + fmt.Sprint(mat[0][1]) + ")"
	return s, f
}

// Проверяет есть ли в матрице хотя бы 1  элемент !=0
func (matrixStruct *Matrix) checkAllElements() bool {
	for index, _ := range matrixStruct.Elements {
		for _, v := range matrixStruct.Elements[index] {
			if v != 0 {
				return true
			}
		}
	}
	return false
}

//	func (matrixStruct *Matrix) Gauss() (s string, f float64) {
//		mat := matrixStruct.Elements
//		//proizv := float64(1)
//		originalLen := len(mat)
//		if originalLen != 3 {
//			return "Правило Саррюса применимо только для матриц размерности 3x3", 0
//		}
//	}
//
// Метод для нахождения det методов треугольника
func (matrixStruct *Matrix) treugolnik(ss string) (s string, f float64) {
	mat := matrixStruct.Elements
	if len(mat) != 3 {
		return "Метод треугольника не применим к матрице не 3x3", 0
	}
	s = ss + " (" + fmt.Sprint(mat[0][0]) + ")*(" + fmt.Sprint(mat[1][1]) + ")*(" + fmt.Sprint(mat[2][2]) + ") +" + " (" + fmt.Sprint(mat[1][0]) + ")*(" + fmt.Sprint(mat[2][1]) + ")*(" + fmt.Sprint(mat[0][2]) + ") +" + " (" + fmt.Sprint(mat[2][0]) + ")*(" + fmt.Sprint(mat[0][1]) + ")*(" + fmt.Sprint(mat[1][2]) + ") -" + " (" + fmt.Sprint(mat[0][0]) + ")*(" + fmt.Sprint(mat[2][1]) + ")*(" + fmt.Sprint(mat[1][2]) + ") -" + " (" + fmt.Sprint(mat[1][0]) + ")*(" + fmt.Sprint(mat[0][1]) + ")*(" + fmt.Sprint(mat[2][2]) + ") -" + " (" + fmt.Sprint(mat[2][0]) + ")*(" + fmt.Sprint(mat[1][1]) + ")*(" + fmt.Sprint(mat[0][2]) + ") = (" + fmt.Sprint(mat[0][0]*mat[1][1]*mat[2][2]) + ") + (" + fmt.Sprint(mat[1][0]*mat[2][1]*mat[0][2]) + ") + (" + fmt.Sprint(mat[2][0]*mat[0][1]*mat[1][2]) + ") - (" + fmt.Sprint(mat[0][0]*mat[2][1]*mat[1][2]) + ") - (" + fmt.Sprint(mat[1][0]*mat[0][1]*mat[2][2]) + ") - (" + fmt.Sprint(mat[2][0]*mat[1][1]*mat[0][2]) + ") = "
	f = mat[0][0]*mat[1][1]*mat[2][2] + mat[1][0]*mat[2][1]*mat[0][2] + mat[2][0]*mat[0][1]*mat[1][2] - mat[0][0]*mat[2][1]*mat[1][2] - mat[1][0]*mat[0][1]*mat[2][2] - mat[2][0]*mat[1][1]*mat[0][2]
	return s, f
}

// Методв для нахождения det методов Саррюса
func (matrixStruct *Matrix) Sarrus(ss string) (s string, f float64) {
	mat := matrixStruct.Elements
	proizv := float64(1)
	originalLen := len(mat)
	if originalLen != 3 {
		return "Правило Саррюса применимо только для матриц размерности 3x3", 0
	}
	newMat1 := mat[0:2][:]
	mat = append(mat, newMat1...)
	for i := 0; i < len(mat)-(originalLen-1); i++ {
		proizv = 1
		if i != 0 {
			s = s + " + "
		}
		s = s + "("
		for j := 0; j < originalLen; j++ {
			if j != 0 {
				s = s + "*"
			}
			s = s + "(" + fmt.Sprint(mat[i+j][0+j]) + ")"
			proizv *= mat[i+j][0+j]
		}
		f += proizv
		s = s + ")"
	}
	for i := len(mat) - 1; i >= originalLen-1; i-- {
		proizv = 1
		if i != len(mat) {
			s = s + " - "
		}
		s = s + "("
		for j := 0; j < originalLen; j++ {
			if j != 0 {
				s = s + "*"
			}
			s = s + "(" + fmt.Sprint(mat[i-j][0+j]) + ")"
			proizv *= mat[i-j][0+j]
		}
		f -= proizv
		s = s + ")"
	}
	return s, f
}

// Транспонирование матрицы. Нужно для функции нахождения определителя методом разложения по строке или столбцу.
func transposeMatrix(mat [][]float64) [][]float64 {
	copyMat := mat
	for i := 0; i < len(mat); i++ {
		for j := 0; j < len(mat); j++ {
			mat[j][i] = copyMat[i][j]
		}
	}
	return mat
}

// Структура содержит матрицу и данные о ней.
type Matrix struct {
	//Двумерная матрица.
	Elements [][]float64
	//Одномерная матрица.
	Element []float64
	//Индекс способа нахождения определителя.
	Sposob int
	//Способ разложения - по строке, столбцу.
	TypeDecomposition string
	//Номер строки или столбца.
	Number int
}

// Проверяет правильно ли заполнена структура.
func (M *Matrix) CheckArguments() bool {
	//Не передана ни 1 матрица.
	if (M.Elements == nil) && (M.Element == nil) {
		return false
	}
	//Переданы сразу две матрицы.
	if (M.Elements != nil) && (M.Element != nil) {
		return false
	}
	//Проверяем двумерную матрицу.
	if M.Elements != nil {
		//Не пустая ли матрица.
		if len(M.Elements) == 0 {
			return false
		}
		//Квадратна ли матрица.
		for _, v := range M.Elements {
			if len(v) != len(M.Elements) {
				M.makeSquare()
			}
		}
	} else {
		//Не пустая ли одномерная матрица.
		if len(M.Element) == 0 {
			return false
		}
	}
	return true
}

// Определяет одномерная или двумерная матрица внутри.
func (M *Matrix) findType() int {
	if M.Element != nil {
		return 0
	} else {
		return 1
	}
}

// Проверяет есть ли в матрице не нулевые элементы.
func (M *Matrix) CheckZero() bool {
	for _, v := range M.Elements {
		for _, j := range v {
			if j != 0 {
				return true
			}
		}
	}
	return false
}

// Делает матрицу квадратной
func (M *Matrix) makeSquare() {
	max := len(M.Elements)
	for _, v := range M.Elements {
		if len(v) > max {
			max = len(v)
		}
	}
	if len(M.Elements) < max {
		var temp []float64
		for j := 0; j < max; j++ {
			temp = append(temp, 0)
		}
		for i := 0; i < (max - len(M.Elements)); i++ {
			M.Elements = append(M.Elements, temp)
		}
	}
	for _, v := range M.Elements {
		if len(v) < max {
			for i := 0; i < (max - len(v)); i++ {
				v = append(v, 0)
			}
		}
	}
}
